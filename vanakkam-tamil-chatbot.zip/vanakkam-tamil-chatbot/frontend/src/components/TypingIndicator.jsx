export default function TypingIndicator() {
  return <div className="bot">சிந்திக்கிறது...</div>;
}
