import { useState } from "react";
import { sendMessage } from "../api";
import Message from "./Message";
import TypingIndicator from "./TypingIndicator";

export default function Chat() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSend() {
    if (!input.trim()) return;

    const userMsg = { role: "user", text: input };
    setMessages(m => [...m, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const reply = await sendMessage(input);
      setMessages(m => [...m, { role: "bot", text: reply }]);
    } catch {
      setMessages(m => [...m, { role: "bot", text: "சேவையக பிழை ஏற்பட்டுள்ளது." }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="chat-container">
      <h2>வணக்கம் – Tamil AI</h2>

      <div className="messages">
        {messages.map((m, i) => (
          <Message key={i} {...m} />
        ))}
        {loading && <TypingIndicator />}
      </div>

      <div className="input-box">
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="தமிழில் எழுதுங்கள்..."
          onKeyDown={e => e.key === "Enter" && handleSend()}
        />
        <button onClick={handleSend}>அனுப்பு</button>
      </div>
    </div>
  );
}
