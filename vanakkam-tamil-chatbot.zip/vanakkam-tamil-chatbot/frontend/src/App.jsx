import Chat from "./components/Chat";

export default function App() {
  return <Chat />;
}
