from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime

from .models import ChatRequest, ChatResponse
from .prompts import BASE_PROMPT
from .gemini import generate_reply
from .utils import format_error

app = FastAPI(title="Vanakkam Tamil AI")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def health():
    return {"status": "healthy", "time": datetime.now().isoformat()}

@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    try:
        full_prompt = f"{BASE_PROMPT}\nபயனர்: {req.message}"
        reply = generate_reply(full_prompt)
        return ChatResponse(response=reply)
    except Exception:
        raise HTTPException(status_code=500, detail=format_error(""))
